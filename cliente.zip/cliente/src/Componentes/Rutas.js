import React from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route} from 'react-router-dom'
import VentanaInicial from './VentanaInicial/VentanaInicial.js'
import VentanaPrincipal from './VentanaPrincipal/VentanaPrincipal.js'


function Rutas(){
  return (
    <Router>
      <Routes>
        <Route path="/" element={<VentanaInicial/>} />
        <Route path="/principal" element={<VentanaPrincipal/>} />
      </Routes>
    </Router>
  )
}

export default Rutas