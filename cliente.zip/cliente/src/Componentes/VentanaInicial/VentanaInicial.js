import './VentanaInicial.css'
import { useState } from 'react'
import { useDispatch } from 'react-redux'
import {setNickName} from '../../redux/slices/infoUsuarioSlice'
import { useNavigate } from 'react-router-dom';

function VentanaInicial(){
  //const nickname = useSelector((state) => state.infoUsuario.nickname)      // obtiene la info
  const dispatch = useDispatch()
  const [nickName, setNickname] = useState("")
  const navigate = useNavigate();

  function PasarVentanaP(){
    if (nickName != ""){
      dispatch(setNickName(nickName));
      navigate('/principal');
    }
  } 
  
  return (
  <div className="App">
    <header className="App-header"> 
      <a className='Titulo'>
      Carreras LuiKi-Kart
      </a>
      <form>
        <a>Ingrese el nickname: </a>
        <input type = "text" nick="nombre" onChange={e => setNickname(e.target.value)}/>
        <button className='BotonConf'
          onClick={PasarVentanaP} >
            Siguiente
        </button>
      </form>
    </header>
  </div>                      
  )
}
export default VentanaInicial