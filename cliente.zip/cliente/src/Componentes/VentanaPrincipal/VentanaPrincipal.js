import './VentanaPrincipal.css'
//import { useState } from 'react'
//import { useHistory } from "react-router-dom";

function VentanaPrincipal(){
  return (
  <div className="App">
    <header className="App-header"> 
      <a className='Titulo'>
      Opciones
      </a>
      <form>
        <button className='BotonConf'
          onClick={console.log("Crear Partida")} >
            Crear Partida
        </button>
      </form>
      <form>
        <button className='BotonConf'
          onClick={console.log("Unirse a una Partida")} >
            Unirse a una Partida
        </button>
      </form>
      <form>
        <button className='BotonConf'
          onClick={console.log("Ver Ranking")} >
            Ver Ranking
        </button>
      </form>
    </header>
  </div>                      
  )
}
export default VentanaPrincipal