import { createSlice } from '@reduxjs/toolkit'

export const infoUsuarioSlice = createSlice({
  name: 'infoUsuario',
  initialState: {
    nickname: "",
    ficha: "",
    idPartida: "",
  },
  reducers: {
    setNickName: (state,action) => {
        state.nickname = action.payload
    },
    setFicha: (state,action) => {
        state.ficha = action.payload
    },
    setIDPartida: (state,action) => {
        state.idPartida = action.payload
    },
  },
})

// Action creators are generated for each case reducer function
export const { setNickName, setFicha, setIDPartida } = infoUsuarioSlice.actions
export default infoUsuarioSlice.reducer