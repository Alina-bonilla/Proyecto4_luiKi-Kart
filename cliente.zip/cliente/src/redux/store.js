import { configureStore } from "@reduxjs/toolkit";
import infoUsuarioSlice from "./slices/infoUsuarioSlice.js";
import { persistReducer, persistStore } from 'redux-persist';
// import storageSession from "redux-persist/lib/storage/session";
import { combineReducers } from "@reduxjs/toolkit";
import storage from 'redux-persist/lib/storage';
//import thunk from 'redux-thunk';
import {
  FLUSH,  REHYDRATE,  PAUSE,  PERSIST,  PURGE,  REGISTER,
} from 'redux-persist'

const persistConfig = {
  key: 'root',
  version: 1,
  storage,
}

const rootReducer = combineReducers({ 
  infoUsuario: infoUsuarioSlice
})

const persistedReducer = persistReducer(persistConfig, rootReducer)

export let store = configureStore({
  reducer: persistedReducer,
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActions: [FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER],
      },
    }),
})

export const persistor = persistStore(store)