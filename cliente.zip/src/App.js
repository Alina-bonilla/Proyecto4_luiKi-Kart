import Rutas from './Componentes/Rutas'

function App() {
  return (
    <Rutas/>
  );
}

export default App;