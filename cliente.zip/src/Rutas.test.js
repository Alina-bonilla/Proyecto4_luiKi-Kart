import { render, screen } from '@testing-library/react';
import App from './Rutas';

test('renders learn react link', () => {
  render(<Ruta />);
  const linkElement = screen.getByText(/learn react/i);
  expect(linkElement).toBeInTheDocument();
});
