import React from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route} from 'react-router-dom'
import VentanaInicial from './VentanaInicial/VentanaInicial.js'
import VentanaPrincipal from './VentanaPrincipal/VentanaPrincipal.js'
import CrearPartida from "./CrearPartida/CrearPartida.js";
import SeleccionarPartida from "./SeleccionarPartida/SeleccionarPartida.js";
import ConfigurarPartida from "./ConfigurarPartida/ConfigurarPartida.js";
import VentanaJuego from "./VentanaJuego/VentanaJuego.js";
import VerRanking from "./VerRanking/VerRanking.js";
import VerEstadistico from "./VerEstadisticos/VerEstadisticos";

function Rutas(){
  return (
    <Router>
      <Routes>
        <Route path="/" element={<VentanaInicial/>} />
        <Route path="/principal" element={<VentanaPrincipal/>} />
        <Route path="/crearPartida" element={<CrearPartida/>} />
        <Route path="/unirsePartida" element={<SeleccionarPartida/>} />
        <Route path="/confiPartida" element={<ConfigurarPartida/>} />
        <Route path="/jugarPartida" element={<VentanaJuego/>} />
        <Route path="/verRanking" element={<VerRanking/>} /> 
        <Route path="/verEstadistico" element={<VerEstadistico/>} /> 
      </Routes>
    </Router>
  )
}

export default Rutas