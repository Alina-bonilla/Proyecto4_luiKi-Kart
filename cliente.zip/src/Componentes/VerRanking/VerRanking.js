import "./VerRanking.css";
import axios from "axios";
import { useState } from "react"
import { useSelector } from "react-redux"
import { useEffect } from "react"

axios.defaults.baseURL = 'http://localhost:3001';

function VerRanking() {
    const nickname = useSelector((state) => state.infoUsuario.nickname)
    const [lista, SetRanking] = useState([])

    useEffect(() => {
        axios.get( `/api/juego/Ranking`)
        .then(function (response) {
            console.log(response.data);
            SetRanking(response.data.listaRanking);
        })
    })
    
    return (<div className="FondoVR">
    <h1 className='LabelNickVR'>
      {"Nombre:\t" + nickname}
    </h1>
    <h1 className="TituloVR">
      Ver Ranking
    </h1>
    <contener className="ContenedorTablaVR">
        <table className = "TablaVR">
        <caption className="CaptionVR">
            Ganadores por partida
        </caption>
        <thead>
            <tr >
            <th className="BordeVR"> Nickname </th>
            <th className="BordeVR"> Tiempo </th>
            <th className="BordeVR"> Pista </th>
            <th className="BordeVR"> Vueltas </th>
            <th className="BordeVR"> Id Partida </th>
            <th className="BordeVR"> Tipo de Partida </th>
            </tr>
        </thead>
        <tbody>
            {lista.map(product => (
            <tr key={product.Nickname}>
                <td className="BordeVR">{product.Nickname}</td>
                <td className="BordeVR">{product.Tiempo}</td>
                <td className="BordeVR">{product.Pista}</td>
                <td className="BordeVR">{product.Vueltas}</td>
                <td className="BordeVR">{product.IdPartida}</td>
                <td className="BordeVR">{product.TipoPartida}</td>
            </tr>
            ))}
        </tbody>
        </table>
    </contener>
    </div>);
  }

export default VerRanking;