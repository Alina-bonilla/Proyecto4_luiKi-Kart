import "./VentanaJuego.css"
import { useDispatch, useSelector } from "react-redux"
import { useCallback, useState } from "react"
import axios from "axios"
import { useEffect } from "react"
import { setMartizJugadores, setEspera } from "../../redux/slices/infoPartidaSlice";

function VentanaJuego() {
  const idPartida = useSelector((state) => state.infoPartida.idPartida)
  const nombrePista = useSelector((state) => state.infoPartida.nombrePista)
  const cantidad = useSelector((state) => state.infoPartida.cantidad)
  const totalVueltas = useSelector((state) => state.infoPartida.totalVueltas)
  const pista = useSelector((state) => state.infoPartida.pista)
  const ficha = useSelector((state) => state.infoPartida.ficha)

  const dispatch = useDispatch();

  const martizJugadores = useSelector((state) => state.infoPartida.martizJugadores)
  const nickname = useSelector((state) => state.infoUsuario.nickname)


  const [jugadores, setJugadores] = useState([])
  const [cronometro, setCronometro] = useState("00:00:00")
  const [jugando, setJugando] = useState(false);
  const [enEspera, setenEspera] = useState(true);

  let intervalJugadores = null;
  let intervalMatrizJugadores = null;

  useEffect(() => {
    if (!intervalJugadores) {
      intervalJugadores = setInterval(() => {
        // console.log("martizJugadores:\t", martizJugadores);
        // console.log("martizJugadores === []:\t", martizJugadores === []);
        if (martizJugadores === []) {
          axios.get(`/api/juego/GetJugadoresFichas?idPartida=${idPartida}`)
            .then(function (response) {
              setJugadores(response.data.jugadores.filter((item) => item.nombre !== nickname));
              clearInterval(intervalJugadores);
              intervalJugadores = null;
            }).catch((err) => {
              console.log(err)
            })
        }
      }, 1000)
    }
  });


  useEffect(() => {
    if (!intervalMatrizJugadores) {
      intervalMatrizJugadores = setInterval(() => {
        axios.get(`/api/juego/GetMatrizJugadores?idPartida=${idPartida}`)
          .then(function (response) {
            console.log('get matriz', response.data);
            dispatch(setMartizJugadores(response.data.martizJugadores));
            setCronometro(response.data.cronometro);
            clearInterval(intervalMatrizJugadores);
            intervalMatrizJugadores = null;
          }).catch((err) => {
            console.log(err)
          })
      }, 1000)
    }
  });

  document.addEventListener("keydown", useCallback(function (event) {
    event.stopImmediatePropagation();
    const key = event.key; // "ArrowRight", "ArrowLeft", "ArrowUp", or "ArrowDown"
    switch (key) {
      case "ArrowLeft":
        MoverFicha("ArrowLeft");
        break;
      case "ArrowRight":
        MoverFicha("ArrowRight");
        break;
      case "ArrowUp":
        MoverFicha("ArrowUp");
        break;
      case "ArrowDown":
        MoverFicha("ArrowDown");
        break;
      case "u":
        if (enEspera) {
          MoverFicha("u");
        }
        break;
      default:
        break;
    }
  }));

  document.addEventListener("keyup", function (event) {
    event.stopImmediatePropagation();
  });

  function MoverFicha(tecla) {
    console.log(tecla);
    axios.post(`/api/juego/Movimiento?idPartida=${idPartida}&nickname=${nickname}&ficha=${ficha}&tecla=${tecla}`, {
      headers: {
        "Content-Type": "application/json",
      }
    })
      .then(function (response) {
        if (response.data.estado === 1) {
          alert(response.data.mensaje);
        } else if (response.data.estado === 2) {
          console.log("e2", response.data);
          dispatch(setEspera(false));
          setenEspera(false);
          setJugando(true);
          console.log("MV jugando", jugando)
        } else if (response.data.estado === 3) {
          dispatch(setMartizJugadores(response.data.martizJugadores));
        } else if (response.data.estado === 4) {
          alert(response.data.mensaje);
        }
        console.log("movimiento si,estado:", response.data.estado);
  })
}

return (
  <div className="FondoVJ">
    <div className="ContenedorInfoPartida1VJ">
      <p>{"Partida\t" + idPartida}</p>
      <p>{"Pista:\t" + nombrePista}</p>
      <p>{"Laps:\t" + cantidad + "/" + totalVueltas}</p>
    </div>
    <div className="ContenedorInfoPartida2VJ">
      <p>Tiempo trasncurrido:</p>
      <p>{cronometro}</p>
    </div>
    <div className="ContenedorInfoPartida3VJ">
      <p>{"Nombre:\t" + nickname}</p>
    </div>
    <div className="ContenedorInfoPartida4VJ" key={"CIP2"}>
      <p key={"SB2"}>Lista Jugadores conectados:</p>
      <div className="ListaJugadoresVJ" key={"CIP2"}>
        <ol>
          {
            jugadores.map((jugador, index) => {
              return <li key={index}>{
                (jugador.ficha !== "") ? jugador.nombre + "\tFicha:\t" + jugador.ficha : ""
              }</li>
            })}
        </ol>
      </div>
    </div>
    <div className="ContenedorInfoPartida5VJ" key={"tabla"}>
      {pista.map((fila, index) =>
        <tr key={"fila" + index}>
          {fila.map((casilla, indice) =>
            <td key={"f" + index + "c" + indice} className={(casilla === "x") ? "CasillaXJuegoVJ" : (casilla === "0") ? "CasillaInicioFinJuegoVJ" : "CasillaCaminoJuegoVJ"}></td>
          )}
        </tr>
      )}

    </div>
    {/* <div className="ContenedorInfoPartida5VJ" key={"Ttabla"}>
        {martizJugadores.map((fila, index) =>
          <tr key={"Tfila" + index}>
            {fila.map((casilla, indice) =>
              <td key={"Tf" + index + "c" + indice} className={"CasillaJVJ"}>{
                "".join(casilla[1])
              }</td>
            )}
          </tr>
        )}
      </div> */}
  </div>
)
}

export default VentanaJuego;