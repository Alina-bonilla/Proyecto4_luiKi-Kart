import './VentanaPrincipal.css'
import { useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom';

function VentanaPrincipal(){
  const nickname = useSelector((state) => state.infoUsuario.nickname)
  const navigate = useNavigate();

  function PasarCrearPart(){
    navigate('/crearPartida');
  } 

  function PasarUnirsePart(){
    navigate('/unirsePartida');
  } 

  function PasarVerRanking(){ 
    navigate('/verRanking');
  }

  function PasarVerEstadistico(){ 
    navigate('/verEstadistico');
  }

  return (
  <div className="FondoVP">
    <h1 className='LabelNickVP'>
      {"Nombre:\t" + nickname}
    </h1>
    <h2 className = "TituloVP">
    Opciones
    </h2>
    <header className="BodyVP"> 
      <div>
        <button className='BotonOpc'
          onClick={PasarCrearPart} >
            Crear Partida
        </button>
      </div>
      <div>
        <button className='BotonOpc'
          onClick={PasarUnirsePart}>
            Unirse a una Partida
        </button>
      </div>
      <div>
        <button className='BotonOpc'  
          onClick={PasarVerRanking} >
            Ver Ranking 
        </button>
      </div>
      <div>
        <button className='BotonOpc'  
          onClick={PasarVerEstadistico} >
            Ver Estadisticas 
        </button>
      </div>
    </header>
  </div>                      
  )
}
export default VentanaPrincipal