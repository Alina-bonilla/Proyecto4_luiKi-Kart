import './VentanaInicial.css'
import { useState } from 'react'
import { useDispatch } from 'react-redux'
import {setNickName} from '../../redux/slices/infoUsuarioSlice'
import { useNavigate } from 'react-router-dom';

function VentanaInicial(){
  const dispatch = useDispatch()
  const [nickName, setNickname] = useState("")
  const navigate = useNavigate();

  function PasarVentanaP(){
    if (nickName !== ""){
      dispatch(setNickName(nickName));
      navigate('/principal');
    }
  } 

  function keyPress(event){
    if (event.key ==='Enter'){
      PasarVentanaP()
    }
  }

  return (
  <div className="FondoVI">
    <h2 className='TituloVI'>
      Carreras LuiKi-Kart
      <header className="BodyVI"> 
        <form>
          <h3>Ingrese el nickname: </h3>
          <input type = "text" nick="nombre" onChange={e => setNickname(e.target.value)} onKeyDown = {keyPress}/>
          <button className='BotonSig'
            onClick={PasarVentanaP} >
              Siguiente
          </button>
        </form>
      </header>
    </h2>
    
  </div>                      
  )
}
export default VentanaInicial