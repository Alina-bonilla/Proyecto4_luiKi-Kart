import "./ConfigurarPartida.css"
import { useState } from "react"
import { useSelector } from "react-redux"
import { useDispatch } from 'react-redux'
import { useEffect } from "react"
import { setFicha,setPista,setNombrePista, setTotalVueltas } from "../../redux/slices/infoPartidaSlice";
import axios from "axios"
import { useNavigate } from 'react-router-dom';

axios.defaults.baseURL = 'http://localhost:3001';

function ConfigurarPartida() {
  const dispatch = useDispatch()
  const navigate = useNavigate();

  const nickname = useSelector((state) => state.infoUsuario.nickname)
  const idPartida = useSelector((state) => state.infoPartida.idPartida)
  const [ficha, SetFicha] = useState("")

  const [fichas, SetFichas] = useState([])
  const [pista, setPistaNombre] = useState("")
  const [cantidad, setCantidad] = useState("")
  const [tjuego, setTipoJuego] = useState("")
  const [jugadores,setJugadores] = useState([])

  useEffect(() => {
    axios.get( `/api/juego/GetFichas?idPartida=${idPartida}`)
      .then(function (response) {
        SetFichas(response.data.fichas);
      })
  })

  useEffect(() => {
    if (idPartida !== "") {
      axios.get(`/api/juego/GetInfoPartida?idPartida=${idPartida}`)
        .then(function (response) {
          setPistaNombre(response.data.pista)
          setCantidad(response.data.cantidad)
          setTipoJuego(response.data.tjuego)
        }).catch((err) => {
          console.log(err)
        })
    }else{
      setPistaNombre("")
      setCantidad("")
      setTipoJuego("")
    }
  }, [idPartida])

  useEffect(() => {
    axios.get(`/api/juego/GetJugadoresFichas?idPartida=${idPartida}`)
    .then(function (response) {
        if ((response.data.jugadores).length > 0){
          setJugadores(response.data.jugadores.filter((item)=> item.nombre !== nickname));
        }else{
          alert("Se vencio la partida por falta de jugadores.")
          navigate("/principal");
        }
    }).catch((err) => {
        console.log(err)
    })
  })

  function IniciarPartida(){
    if (ficha !== ""){
      axios.post(`/api/juego/SeleccionarFicha?idPartida=${idPartida}&nickname=${nickname}&ficha=${ficha}`,{
        headers: {
          "Content-Type": "application/json",
        }})
        .then (function (response){
          console.log("hola",response.data.idPartida);
          console.log("hola2",idPartida);
          if(response.data.idPartida ===parseInt(idPartida)){
            dispatch(setFicha(ficha));
            dispatch(setPista(response.data.matriz));
            dispatch(setNombrePista(pista));
            dispatch(setTotalVueltas(cantidad));
            navigate("/jugarPartida");
          }else{
            alert("Se vencio la partida por falta de jugadores.")
            navigate("/principal");
          }
        })
    }
  };

  return <div className="FondoCFP">
    <h1 className='LabelNickCFP'>
      {"Nombre:\t" + nickname}
    </h1>
    <h1 className="TituloCFP">
      {"Partida\t"+idPartida}
    </h1>

    <h1 className="LabelTextCFP">
      {"Seleccione  la ficha a usar en la partida:\t"}
      <select className='SelectorPistasCFP' id="IDPartidaDropDown" onChange={e => SetFicha(e.target.value)}>
        <option key={""} value="">Seleccione la ficha</option>
        {fichas.map((idpartida, index) => {
            return <option key={index} value={idpartida}>{idpartida}</option>
          })}
      </select>
    </h1>
    <div className="LabelInfopartidaCFP" key={"LIFP"}>
      <h3 className="Subtitulo1CFP" key={"SB1"}>Informacion de la partida:</h3>
      <div className="ContenedorInfoPartida1CFP" key={"CIP1"}>
        <p className="InfoPartida1CFP" key={"pista"}>
          {"Pista:\t" + pista}
        </p>
        <p className="InfoPartida2CFP" key={"cantidad"}>
          {"Cantidad de vueltas:\t" + cantidad}
        </p>
        <p className="InfoPartida3CFP" key={"tjuego"}>
          {"Tipo de juego:\t" + tjuego}
        </p>
      </div>
      <h3 className="Subtitulo2CFP" key={"SB2"}>Lista Jugadores conectados:</h3>
      <div className="ContenedorInfoPartida2CFP" key={"CIP2"}>
        <ol>
          {
            jugadores.map((jugador, index) => { 
              return <li key={index}>{
                (jugador.ficha !=="") ? jugador.nombre + "\tFicha:\t" + jugador.ficha : jugador.nombre
              }</li>
            })}
        </ol>
      </div>
    </div>
    
    <h1 className="ContenedorBotonCFP">
      <button className='BotonConfCFP' onClick={IniciarPartida}>
        Jugar
      </button>
    </h1>
  </div>
}

export default ConfigurarPartida;