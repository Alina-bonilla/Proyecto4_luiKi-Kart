import "./SeleccionarPartida.css"
import { useState } from "react"
import { useSelector } from "react-redux"
import { useDispatch } from 'react-redux'
import { useEffect } from "react"
import { setIDPartida } from "../../redux/slices/infoPartidaSlice";
import axios from "axios"
import { useNavigate } from 'react-router-dom';


function SeleccionarPartida() {
  const dispatch = useDispatch()
  const navigate = useNavigate();

  const nickname = useSelector((state) => state.infoUsuario.nickname)
  const [idPartidas, SetIDPartidas] = useState([])
  const [idPartida, SetIDPartida] = useState("")

  const [pista, setPista] = useState("")
  const [cantidad, setCantidad] = useState("")
  const [tjuego, setTipoJuego] = useState("")
  const [jugadores,setJugadores] = useState([])

  useEffect(() => {
    axios.get("/api/juego/GetIDPartidas")
      .then(function (response) {
        SetIDPartidas(response.data.idPartidas);
      })
  })

  useEffect(() => {
    if (idPartida !== "") {
      axios.get(`/api/juego/GetInfoPartida?idPartida=${idPartida}`)
        .then(function (response) {
          setPista(response.data.pista)
          setCantidad(response.data.cantidad)
          setTipoJuego(response.data.tjuego)
          setJugadores(response.data.nombreJugadores)
        }).catch((err) => {
          console.log(err)
        })
    }else{
      setPista("")
      setCantidad("")
      setTipoJuego("")
      setJugadores([])
    }
  }, [idPartida])

  function UnirsePartida(){
    if (idPartida === ""){
      setCantidad(2);
    }else{
      axios.post(`/api/juego/AgregarJugador?idPartida=${idPartida}&nickname=${nickname}`,{
        headers: {
          "Content-Type": "application/json",
        }})
        .then (function (response){
          if(response.data.idPartida !== ""){
            dispatch(setIDPartida(response.data.idPartida));
            navigate("/confiPartida");
          }else{
            setPista("")
            setCantidad("")
            setTipoJuego("")
            setJugadores([])
          }
        })
    }
  };

  return <div className="FondoSLP">
    <h1 className='LabelNickSLP'>
      {"Nombre:\t" + nickname}
    </h1>
    <h1 className="TituloSLP">
      Unirse a Partida
    </h1>

    <h1 className="LabelTextSLP">
      {"Seleccione el ID de la partida deseada:\t"}
      <select className='SelectorPistasSLP' id="IDPartidaDropDown" onChange={e => SetIDPartida(e.target.value)}>
        <option key={""} value="">Seleccione un ID</option>
        {idPartidas.map((idpartida, index) => {
            return <option key={index} value={idpartida}>{idpartida}</option>
          })}
      </select>
    </h1>
    <div className="LabelInfopartidaSLP" key={"LIFP"}>
      <h3 className="Subtitulo1SLP" key={"SB1"}>Informacion de la partida:</h3>
      <div className="ContenedorInfoPartida1SLP" key={"CIP1"}>
        <p className="InfoPartida1SLP" key={"pista"}>
          {"Pista:\t" + pista}
        </p>
        <p className="InfoPartida2SLP" key={"cantidad"}>
          {"Cantidad de vueltas:\t" + cantidad}
        </p>
        <p className="InfoPartida3SLP" key={"tjuego"}>
          {"Tipo de juego:\t" + tjuego}
        </p>
      </div>
      <h3 className="Subtitulo2SLP" key={"SB2"}>Lista Jugadores conectados:</h3>
      <div className="ContenedorInfoPartida2SLP" key={"CIP2"}>
        <ol>
          {
            jugadores.map((jugador, index) => { 
              return <li key={index}>{jugador}</li>
            })}
        </ol>
      </div>
    </div>
    
    <h1 className="ContenedorBotonSLP">
      <button className='BotonConfSLP' onClick={UnirsePartida}>
        Unirse
      </button>
    </h1>
  </div>
}

export default SeleccionarPartida;