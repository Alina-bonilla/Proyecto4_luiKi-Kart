import  "./CrearPartida.css"
import { useState } from "react"
import { useSelector } from "react-redux"
import { useDispatch } from 'react-redux'
import { useEffect } from "react"
import { setPistas,setIDPartida} from "../../redux/slices/infoPartidaSlice";
import axios from "axios"
import { useNavigate } from 'react-router-dom';


function CrearPartida(){
  const dispatch = useDispatch()
  const navigate = useNavigate();

  const nickname = useSelector((state) => state.infoUsuario.nickname)
  const pistas = useSelector((state) => state.infoPartida.pistas)
  const [cantidad, setCantidad] = useState(2)
  const [pista,setPista] = useState("")
  const [tipoJuego,setTipoJuego] = useState(1)

  useEffect(()=>{
    axios.get("/api/juego/GetPistas")
    .then (function (response){ 
      dispatch(setPistas(response.data));
    })
  })

  useEffect(()=>{
    setPista(pistas[0])
  },[pistas])

  function CrearPartidaVS(){
    if (cantidad < 2){
      setCantidad(2);
    }else{
      axios.post("/api/juego/CrearPartida",{cantidad:cantidad,pista:pista,tipoJuego:tipoJuego,nickname:nickname},{
        headers: {
          "Content-Type": "application/json",
        }})
        .then (function (response){
          dispatch(setIDPartida(response.data.idPartida));
          navigate("/confiPartida");
        })
    }
  };

  return <div className = "FondoCrP">
      <h1 className='LabelNickCrP'>
        {"Nombre:\t" + nickname}
      </h1>
      <h2 className = "TituloCrP">
        Crear Partida
      </h2>

      <h3 className="LabelTextCrP">
        {"Seleccione la pista deseada:\t"}
        <select className='SelectorPistasCrP' id="pistasDropDown" onChange={e => setPista(e.target.value)}>
          {
          pistas.map((pista,index) => {
            return <option key={index} value={pista}>{pista}</option>
          })}
        </select>
      </h3>

      <h3 className="LabelTextCrP">
        {"Ingrese la cantidad de vueltas deseadas:\t"}  
        <input type = "number" min="2" cantidad="Cantidad" value={cantidad} onChange={e => setCantidad(e.target.value)} className="InputCantidad"/>
      </h3>
      
      <h3 className="LabelTextCrP">
        {"Seleccione el modo de juego deseado:\t"}
        <select className='SelectorTipoJuegoCrP' id="tipoJuegoDropDown" onChange={e => setTipoJuego(e.target.value)}>
          <option value={1}>Vs Jugadores</option>
          <option value={2}>Vs Tiempo</option>
        </select>
      </h3>

      <h3 className="ContenedorBotonCrP">
        <button className='BotonConfCrP' onClick={CrearPartidaVS}>
          Crear Partida
        </button>
      </h3>
    </div>
}

export default CrearPartida;