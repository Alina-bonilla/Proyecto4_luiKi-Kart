import { createSlice } from '@reduxjs/toolkit'

export const infoPartidaSlice = createSlice({
  name: 'infoPartida',
  initialState: {
    totalVueltas: 0,
    cantidad: 0,
    ficha: "",
    idPartida: "",
    pistas: [],
    pista: [],
    nombrePista: "",
    martizJugadores: [],
    timpo: "",
    espera: true,
    /*--------- */
  },
  reducers: {
    setCantidad: (state) => {
      state.cantidad++;
    },
    setFicha: (state, action) => {
      state.ficha = action.payload
    },
    setIDPartida: (state, action) => {
      state.idPartida = action.payload
    },
    setPistas: (state, action) => {
      state.pistas = action.payload
    },
    setPista: (state, action) => {
      state.pista = action.payload
    },
    setMartizJugadores: (state, action) => {
      state.martizJugadores = action.payload
    },
    setTimpo: (state, action) => {
      state.timpo = action.payload
    },
    setNombrePista: (state, action) => {
      state.nombrePista = action.payload
    },
    setTotalVueltas: (state, action) => {
      state.totalVueltas = action.payload
    },
    setEspera: (state, action) => {
      state.espera = action.payload
    }
  },
})

// Action creators are generated for each case reducer function
export const { setCantidad, setFicha, setIDPartida, setPistas, setPista, setMartizJugadores, setTimpo, setNombrePista, setTotalVueltas, setEspera } = infoPartidaSlice.actions
export default infoPartidaSlice.reducer