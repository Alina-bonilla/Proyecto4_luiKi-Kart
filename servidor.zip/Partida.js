class Partida{
  idPartida;
  cantidadVueltas;
  tipoJuego;
  pista;
  matrizJuego;
  jugadores;
  tiempoCreacion;
  tiempoInicio;
  fichas;
  matrizJugadores;

  constructor (idPartida,matrizJuego,cantidadVueltas,tipoJuego,pista,tiempoCreacion){
    this.idPartida = idPartida;
    this.matrizJuego = matrizJuego;
    this.cantidadVueltas = cantidadVueltas;
    this.tipoJuego = tipoJuego;
    this.pista = pista;
    this.tiempoCreacion = tiempoCreacion;
    this.jugadores = [];
    this.fichas = ["★","✪","❆","✩","۞","♞","♛","♗","♟","☀","☢","☠","♆","☣"];
    this.tiempoInicio = null;
    this.matrizJugadores = [];
  }

  AgregarJugador(jugador){
    this.jugadores.push(jugador);
  }

  setFichas(ficha){
    this.fichas = this.fichas.filter((item)=> item !== ficha);
  }

  SetTiempoInicio(tiempoInicio){
    this.tiempoInicio = tiempoInicio;
  }

  SetMatrizJugadores(){    
    this.matrizJuego.forEach((fila,i) => {
      let nFila = [];
      let agregados = false;
      fila.forEach((casilla,j) => {
        if (casilla == "0"){
          if (!agregados){
            let fichas = [];
            this.jugadores.forEach(element => {
              element.i = i
              element.j = j
              if (element.ficha !== ""){              
                fichas.push(element.ficha)
              }
            })
            agregados = !agregados;
            nFila.push([casilla,fichas])
          }else{
            nFila.push([casilla,[]])
          }
        }else{
          nFila.push([casilla,[]])
        }
      });
      this.matrizJugadores.push(nFila);
    });
  }
}

module.exports = Partida