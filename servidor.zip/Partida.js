class Partida{
  idPartida;
  cantidadVueltas;
  tipoJuego;
  pista;
  matrizJuego;
  jugadores;
  tiempoCreacion;
  tiempoInicio;
  fichas;

  constructor (idPartida,matrizJuego,cantidadVueltas,tipoJuego,pista,tiempoCreacion){
    this.idPartida = idPartida;
    this.matrizJuego = matrizJuego;
    this.cantidadVueltas = cantidadVueltas;
    this.tipoJuego = tipoJuego;
    this.pista = pista;
    this.tiempoCreacion = tiempoCreacion;
    this.jugadores = [];
    this.fichas = ["★","✪","❆","✩","۞","♞","♛","♗","♟","☀","☢","☠","♆","☣"];
  }

  AgregarJugador(jugador){
    this.jugadores.push(jugador);
  }

  setFichas(ficha){
    this.fichas = this.fichas.filter((item)=> item !== ficha);
  }

  SetTiempoInicio(tiempoInicio){
    this.tiempoInicio = tiempoInicio;
  }
}

module.exports = Partida