const express = require('express')
const router = express.Router()
const bodyParser = require("body-parser");

//* CONEXION CON SQL */
const sql = require('mssql');
const { request } = require('express');
const { async } = require('walkdir');
const config = {
    user: 'sa',
    password : '1234',
    server: 'DESKTOP-HAE9KG8',//'DESKTOP-93S44CH\\SQLEXPRESS',
    database: 'Juegos',
    "options": {
      "encrypt": true,
      "enableArithAbort": true,
      trustServerCertificate: true
    }
}

//Consulta a la base de datos para las estadisticas
let ProceEstadisticoJugadores = async()=>{ 
  try {
      await sql.connect(config); // conectamos a la DB
      let db = new sql.Request();
      let tablaResult = ('dbo.proceEstadisticoJugadores');
      let result = await db.query(tablaResult); // almacenamos el resultado de la Promesa
      let id = result.recordset; // Obtenemos el id
      return id; // devolvemos el resultado
  } catch (err) {
      console.log(err.message);
      throw err;
  }
}

//Consulta a la base de datos para el ranking
let ProceRanking = async()=>{ 
  try {
      await sql.connect(config); // conectamos a la DB
      let db = new sql.Request();
      let tablaResult = ('dbo.proceRanking');
      let result = await db.query(tablaResult); // almacenamos el resultado de la Promesa
      let id = result.recordset; // Obtenemos el id
      return id; // devolvemos el resultado
  } catch (err) {
      console.log(err.message);
      throw err;
  }
}


//Crear partida
function CrearPartidaSQL (Pista,Vueltas,TipoPartida){        
  sql.connect(config).then(pool => {
    return pool.request()
    .input('pPista', sql.VarChar(40), Pista)
    .input('pVueltas', sql.SmallInt, Vueltas)
    .input('pTipoPartida', sql.TinyInt, TipoPartida)
    .input('pId', sql.Int, 0)
    .execute('dbo.proceCrearPartida')  
  }).then(result =>{
    console.log(result.recordset)
    sql.close();      
    }).catch(err=>{
    console.log(err);
    sql.close();
    });     
}

//Crear jugador
function CrearJugadorSQL (Nombre,Tiempo,Posicion,Partida,VueltasRealizadas){        
  sql.connect(config).then(pool => {
    return pool.request()
    .input('pNickname', sql.VarChar(15), Nombre)
    .input('pTiempo', sql.VarChar(15), Tiempo)
    .input('pPosicion', sql.TinyInt, Posicion)
    .input('pIdPartida', sql.Int, Partida)
    .input('pVueltasRealizadas', sql.SMALLINT, VueltasRealizadas)
    .execute('dbo.proceCrearJugador')  
  }).then(result =>{
    console.log(result.recordset)
    sql.close();      
    }).catch(err=>{
    console.log(err);
    sql.close();
    });     
}

//Extrae el id de la ultima partida creada
let extraerIdPartidaSQL = async()=>{ 
  try {
      await sql.connect(config); // conectamos a la DB
      let db = new sql.Request();
      let nuevoPartida = (`SELECT TOP 1 * FROM Partida ORDER BY IdPartida DESC`);
      let result = await db.query(nuevoPartida); // almacenamos el resultado de la Promesa
      let id = result.recordset[0].IdPartida; // Obtenemos el id
      return id; // devolvemos el resultado
  } catch (err) {
      console.log(err.message);
      throw err;
  }
}


module.exports = {CrearPartidaSQL, extraerIdPartidaSQL, ProceRanking,ProceEstadisticoJugadores,CrearJugadorSQL};



