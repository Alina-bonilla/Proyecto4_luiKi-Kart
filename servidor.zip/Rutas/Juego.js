const Partida = require('../Partida')
const {CrearPartidaSQL,ProceRanking,extraerIdPartidaSQL,ProceEstadisticoJugadores,CrearJugadorSQL} = require('./ConexionBD')

const express = require('express')
const { async } = require('walkdir')
const router = express.Router()
var walk = require("walkdir");
var fs = require("fs");
var bodyParser = require('body-parser');
const Jugador = require('../Jugador')
var jsonParser = bodyParser.json();

var juegos = [];
const MaxTime = 3;

router.get('/GetPistas', async(req,res) => {
  var paths = walk.sync('./pistas');
  var names = new Array();
  paths.forEach(element => names.push(((element.split("\\")[((element.split("\\")).length)-1]).split('.'))[0]));
  return res.status(200).send(names);
});

router.get('/GetIDPartidas', async(req,res) => {
  var idPartidas = new Array()
  var activos = [];
  var cont = 0;  
  while (cont < juegos.length) {
    let paso = ((new Date().getTime() - juegos[cont].tiempoCreacion) < (1000 * 60 * MaxTime)) ? "activo": "inactivo";
    if((paso === "activo") || (juegos[cont].jugadores.length > 1)){
      idPartidas.push(juegos[cont].idPartida);
      activos.push(juegos[cont]);
    }
      cont++;
  };
  juegos = activos;
  return res.status(200).send({idPartidas});
});

router.get('/GetInfoPartida', async(req,res) => {
  var pista = "";
  var cantidad = "";
  var tjuego = "";
  var nombreJugadores = [];
  var cont = 0;
  var activos = [];
  while (cont < juegos.length) {
    let paso = ((new Date().getTime() - juegos[cont].tiempoCreacion) < (1000 * 60 * MaxTime)) ? "activo": "inactivo";
    if((paso === "activo") || (juegos[cont].jugadores.length > 1)){
      if (juegos[cont].idPartida == req.query.idPartida){
        pista = juegos[cont].pista;
        cantidad = juegos[cont].cantidadVueltas;
        if(juegos[cont].tipoJuego === "1"){
          tjuego = "Vs Jugadores";
        }else{
          tjuego = "Vs Tiempo";
        }
        juegos[cont].jugadores.forEach(element => {
          nombreJugadores.push(element.nombre);
        });
      }
      activos.push(juegos[cont]);
    }
    cont++;
  }
  juegos = activos;
  return res.status(200).send({pista,cantidad,tjuego,nombreJugadores});
});

router.get('/GetFichas', async(req,res) => {
  var fichas = [];
  var cont = 0;
  /*var segundos = 0;
  var minutos = 0;
  var horas = 0;*/
  while (cont < juegos.length) {
    let paso = ((new Date().getTime() - juegos[cont].tiempoCreacion) < (1000 * 60 * MaxTime)) ? "activo": "inactivo";
    if(paso === "activo"){
      if (juegos[cont].idPartida == req.query.idPartida){       
        fichas = juegos[cont].fichas
        /*
        let transcurrido = (new Date().getTime() - juegos[cont].tiempoCreacion);
        segundos = ~~(transcurrido / 1000)
        minutos = ~~(transcurrido / 60000)
        horas = ~~(transcurrido / 7200000)
        if (segundos>59){
          segundos -= minutos*60;
        }
        if (minutos>59){
          minutos -= horas*120;
        }
        
        console.log(horas,":",minutos,":",segundos);
        */
      }
    }
    cont++;
  }
  return res.status(200).send({fichas});
});

router.get('/GetJugadoresFichas', async(req,res) => {
  var jugadores = new Array;
  var cont = 0;
  var activos = [];
  while (cont < juegos.length) {
    let paso = ((new Date().getTime() - juegos[cont].tiempoCreacion) < (1000 * 60 * MaxTime)) ? "activo": "inactivo";
    if((paso === "activo") || (juegos[cont].jugadores.length > 1)){
      if (juegos[cont].idPartida == req.query.idPartida){
        juegos[cont].jugadores.forEach(element => {
          let nombre = element.nombre;
          let ficha = element.ficha;
          jugadores.push({nombre,ficha});
        });
      }
      activos.push(juegos[cont]);
    }
    cont++;
  }
  juegos = activos;
  return res.status(200).send({jugadores});
});

router.get('/Ranking', async(req,res) => {
  var listaRanking = await ProceRanking ();
  return res.status(200).send({listaRanking});
});

router.get('/Estadistico', async(req,res) => {
  var listaEstadistico = await ProceEstadisticoJugadores ();
  return res.status(200).send({listaEstadistico});
});

router.get('/GetMatrizJugadores', async(req,res) => {
  var matrizJugadores = [];
  var cont = 0;
  var activos = [];
  while (cont < juegos.length) {
    let paso = ((new Date().getTime() - juegos[cont].tiempoCreacion) < (1000 * 60 * MaxTime)) ? "activo": "inactivo";
    if((paso === "activo") || (juegos[cont].jugadores.length > 1)){
      if (juegos[cont].idPartida == req.query.idPartida){
        matrizJugadores = juegos[cont].matrizJugadores;
      }
      activos.push(juegos[cont]);
    }
    cont++;
  }
  juegos = activos;
  return res.status(200).send({matrizJugadores});
});

/*------------------------------POSTS------------------------------*/
router.post('/CrearPartida',jsonParser, async (req,res) => {
  const body = req.body;
  const file = "./pistas/"+ body.pista +".txt";

  var text = fs.readFileSync(file, "utf-8");
  var lines = text.split("\n");
  var matriz = new Array();
  lines.forEach(element => matriz.push(element.replace("\r",'').split(','))); 
  
  CrearPartidaSQL(body.pista,body.cantidad,body.tipoJuego);
  const idPartida = await extraerIdPartidaSQL();
  //console.log (CrearJugadorSQL('Lulu','00:04:20',2,1,1));//CREADAR JUGADOR

  const d = new Date();
  let time = d.getTime();

  let partida = new Partida(idPartida,matriz,body.cantidad,body.tipoJuego,body.pista,time);
  let jugadorC = new Jugador(body.nickname);
  partida.AgregarJugador(jugadorC);
  juegos.push(partida); 
  let matrizJuego = matriz;
  return res.status(200).send({idPartida,matrizJuego});
});

router.post('/AgregarJugador',jsonParser, async (req,res) => {
  var idPartida = "";
  var pista;
  var cont = 0;
  var activos = [];
  while (cont < juegos.length) {
    let paso = ((new Date().getTime() - juegos[cont].tiempoCreacion) < (1000 * 60 * MaxTime)) ? "activo": "inactivo";
    if((paso === "activo") || (juegos[cont].jugadores.length > 1)){
      if (juegos[cont].idPartida == req.query.idPartida){
        let existe = 0;
        juegos[cont].jugadores.forEach(element => {
          if (element.nombre === req.query.nickname){
            existe = 1;
          }
        }); 
        if (existe === 0){
          let jugador = new Jugador(req.query.nickname);
          juegos[cont].jugadores.push(jugador)
          idPartida = req.query.idPartida
          pista = juegos[cont].matrizJuego
        }
      }
      activos.push(juegos[cont]);
    }
    cont++;
  }
  juegos = activos;
  
  return res.status(200).send({idPartida,pista});
});

router.post('/SeleccionarFicha',jsonParser, async (req,res) => {
  let idPartida = "";
  let matriz = [];
  let pista = "";
  var cont = 0;
  while (cont < juegos.length) {
    let paso = ((new Date().getTime() - juegos[cont].tiempoCreacion) < (1000 * 60 * MaxTime)) ? "activo": "inactivo";
    if(paso === "activo"){
      if (juegos[cont].idPartida == req.query.idPartida){
        juegos[cont].jugadores.forEach(element => {
          if (element.nombre == req.query.nickname){
            juegos[cont].setFichas(req.query.ficha);
            element.setFicha(req.query.ficha);
          }
        })
        idPartida = juegos[cont].idPartida;
        matriz = juegos[cont].matrizJuego;
        pista = juegos[cont].pista;
      }
    }
    cont++;
  }
  return res.status(200).send({idPartida,matriz,pista});
});

router.post('/Movimiento',jsonParser, async (req,res) => {
  console.log(req.query);
  let estado = 0;
  if (req.query.tecla === 'u'){
    var cont = 0;
    while (cont < juegos.length) {
      if (juegos[cont].idPartida == req.query.idPartida){
        let cantJ = 0;
        juegos[cont].jugadores.forEach(element => {
          if(juegos[cont].jugadores.ficha !== ""){
            cantJ++;
          }
        });
        if (cantJ > 1){
          juegos[cont].SetMatrizJugadores();
          juegos[cont].SetTiempoInicio(new Date().getTime());
          console.log(juegos[cont].matrizJugadores);
          estado = 2;
          return res.status(200).send({estado,matrizJugadores:juegos[cont].matrizJugadores});
        }else{
          estado = 1;
          let mensaje = "La partida no puede iniciar aun ya que faltan jugadores."
          return res.status(200).send({estado,mensaje});
        }
      }
      cont++;
    }
  }else{
    var cont = 0;
    while (cont < juegos.length) {
      if (juegos[cont].idPartida == req.query.idPartida){
        if(juegos[cont].matrizJugadores !== []){
          let jugador;
          juegos[cont].jugadores.forEach(element => {
            if (element.nombre === req.query.nickname){
              jugador = element
            }
          });
          let [i,j] = [jugador.i,jugador.j]
          switch (req.query.tecla){
            case "ArrowLeft":
              //MoverFicha("ArrowLeft");
              if (i-1 >= 0){
                if (juegos[cont].matrizJugadores[i-1][j][0] !== "x"){
                  juegos[cont].matrizJugadores[i-1][j][1],push(jugador.ficha)
                  juegos[cont].matrizJugadores[i][j][1] = juegos[cont].matrizJugadores[i][j][1].Filter(elemento => {if(elemento != jugador.ficha)return elemento})
                  jugador.i --; 
                }
              }

            case "ArrowRight":
              //MoverFicha("ArrowRight");
              if (i+1 < 25){
                if (juegos[cont].matrizJugadores[i+1][j][0] !== "x"){
                  juegos[cont].matrizJugadores[i+1][j][1],push(jugador.ficha)
                  juegos[cont].matrizJugadores[i][j][1] = juegos[cont].matrizJugadores[i][j][1].Filter(elemento => {if(elemento != jugador.ficha)return elemento})
                  jugador.i ++; 
                }
              }
            case "ArrowUp":
              //MoverFicha("ArrowUp");
              if (j-1 < 25){
                if (juegos[cont].matrizJugadores[i][j-1][0] !== "x"){
                  juegos[cont].matrizJugadores[i][j-1][1],push(jugador.ficha)
                  juegos[cont].matrizJugadores[i][j][1] = juegos[cont].matrizJugadores[i][j][1].Filter(elemento => {if(elemento != jugador.ficha)return elemento})
                  jugador.j --; 
                }
              }
            default:
              //MoverFicha("ArrowDown");
              if (j+1 < 25){
                if (juegos[cont].matrizJugadores[i][j+1][0] !== "x"){
                  juegos[cont].matrizJugadores[i][j+1][1],push(jugador.ficha)
                  juegos[cont].matrizJugadores[i][j][1] = juegos[cont].matrizJugadores[i][j][1].Filter(elemento => {if(elemento != jugador.ficha)return elemento})
                  jugador.j ++; 
                }
              }
          
          }
        }
        cont = juegos.length;
      }
      cont++;
    }
  }
  return res.status(200).send({estado,mensaje:"Error"});
});

module.exports = router;