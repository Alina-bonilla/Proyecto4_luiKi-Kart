const Partida = require('../Partida')
const {CrearPartidaSQL,ProceRanking,extraerIdPartidaSQL,ProceEstadisticoJugadores,CrearJugadorSQL} = require('./ConexionBD')

const express = require('express')
const { async } = require('walkdir')
const router = express.Router()
var walk = require("walkdir");
var fs = require("fs");
var bodyParser = require('body-parser');
const Jugador = require('../Jugador')
var jsonParser = bodyParser.json();

var juegos = [];
const MaxTime = 3;

router.get('/GetPistas', async(req,res) => {
  var paths = walk.sync('./pistas');
  var names = new Array();
  paths.forEach(element => names.push(((element.split("\\")[((element.split("\\")).length)-1]).split('.'))[0]));
  return res.status(200).send(names);
});

router.get('/GetIDPartidas', async(req,res) => {
  var idPartidas = new Array()
  var activos = [];
  var cont = 0;  
  while (cont < juegos.length) {
    let paso = ((new Date().getTime() - juegos[cont].tiempoCreacion) < (1000 * 60 * MaxTime)) ? "activo": "inactivo";
    if((paso === "activo") || (juegos[cont].jugadores.length > 1)){
      idPartidas.push(juegos[cont].idPartida);
      activos.push(juegos[cont]);
    }
      cont++;
  };
  juegos = activos;
  return res.status(200).send({idPartidas});
});

router.get('/GetInfoPartida', async(req,res) => {
  var pista = "";
  var cantidad = "";
  var tjuego = "";
  var nombreJugadores = [];
  var cont = 0;
  var activos = [];
  while (cont < juegos.length) {
    let paso = ((new Date().getTime() - juegos[cont].tiempoCreacion) < (1000 * 60 * MaxTime)) ? "activo": "inactivo";
    if((paso === "activo") || (juegos[cont].jugadores.length > 1)){
      if (juegos[cont].idPartida == req.query.idPartida){
        pista = juegos[cont].pista;
        cantidad = juegos[cont].cantidadVueltas;
        if(juegos[cont].tipoJuego === "1"){
          tjuego = "Vs Jugadores";
        }else{
          tjuego = "Vs Tiempo";
        }
        juegos[cont].jugadores.forEach(element => {
          nombreJugadores.push(element.nombre);
        });
      }
      activos.push(juegos[cont]);
    }
    cont++;
  }
  juegos = activos;
  return res.status(200).send({pista,cantidad,tjuego,nombreJugadores});
});

router.get('/GetFichas', async(req,res) => {
  var fichas = [];
  var cont = 0;
  /*var segundos = 0;
  var minutos = 0;
  var horas = 0;*/
  while (cont < juegos.length) {
    let paso = ((new Date().getTime() - juegos[cont].tiempoCreacion) < (1000 * 60 * MaxTime)) ? "activo": "inactivo";
    if(paso === "activo"){
      if (juegos[cont].idPartida == req.query.idPartida){       
        fichas = juegos[cont].fichas
        /*
        let transcurrido = (new Date().getTime() - juegos[cont].tiempoCreacion);
        segundos = ~~(transcurrido / 1000)
        minutos = ~~(transcurrido / 60000)
        horas = ~~(transcurrido / 7200000)
        if (segundos>59){
          segundos -= minutos*60;
        }
        if (minutos>59){
          minutos -= horas*120;
        }
        
        console.log(horas,":",minutos,":",segundos);
        */
      }
    }
    cont++;
  }
  return res.status(200).send({fichas});
});

router.get('/GetJugadoresFichas', async(req,res) => {
  var jugadores = new Array;
  var cont = 0;
  var activos = [];
  while (cont < juegos.length) {
    let paso = ((new Date().getTime() - juegos[cont].tiempoCreacion) < (1000 * 60 * MaxTime)) ? "activo": "inactivo";
    if((paso === "activo") || (juegos[cont].jugadores.length > 1)){
      if (juegos[cont].idPartida == req.query.idPartida){
        juegos[cont].jugadores.forEach(element => {
          let nombre = element.nombre;
          let ficha = element.ficha;
          jugadores.push({nombre,ficha});
        });
      }
      activos.push(juegos[cont]);
    }
    cont++;
  }
  juegos = activos;
  return res.status(200).send({jugadores});
});

router.get('/Ranking', async(req,res) => {
  var listaRanking = await ProceRanking ();
  return res.status(200).send({listaRanking});
});

router.get('/Estadistico', async(req,res) => {
  var listaEstadistico = await ProceEstadisticoJugadores ();
  return res.status(200).send({listaEstadistico});
});

/*------------------------------POSTS------------------------------*/
router.post('/CrearPartida',jsonParser, async (req,res) => {
  const body = req.body;
  const file = "./pistas/"+ body.pista +".txt";

  var text = fs.readFileSync(file, "utf-8");
  var lines = text.split("\n");
  var matriz = new Array();
  lines.forEach(element => matriz.push(element.replace("\r",'').split(','))); 
  
  CrearPartidaSQL(body.pista,body.cantidad,body.tipoJuego);
  const idPartida = await extraerIdPartidaSQL();
  //console.log (CrearJugadorSQL('Lulu','00:04:20',2,1,1));//CREADAR JUGADOR

  const d = new Date();
  let time = d.getTime();

  let partida = new Partida(idPartida,matriz,body.cantidad,body.tipoJuego,body.pista,time);
  let jugadorC = new Jugador(body.nickname);
  partida.AgregarJugador(jugadorC);
  juegos.push(partida); 
  let matrizJuego = matriz;
  return res.status(200).send({idPartida,matrizJuego});
});

router.post('/AgregarJugador',jsonParser, async (req,res) => {
  var idPartida = "";
  var pista;
  var cont = 0;
  var activos = [];
  while (cont < juegos.length) {
    let paso = ((new Date().getTime() - juegos[cont].tiempoCreacion) < (1000 * 60 * MaxTime)) ? "activo": "inactivo";
    if((paso === "activo") || (juegos[cont].jugadores.length > 1)){
      if (juegos[cont].idPartida == req.query.idPartida){
        let existe = 0;
        juegos[cont].jugadores.forEach(element => {
          if (element.nombre === req.query.nickname){
            existe = 1;
          }
        }); 
        if (existe === 0){
          let jugador = new Jugador(req.query.nickname);
          juegos[cont].jugadores.push(jugador)
          idPartida = req.query.idPartida
          pista = juegos[cont].matrizJuego
        }
      }
      activos.push(juegos[cont]);
    }
    cont++;
  }
  juegos = activos;
  
  return res.status(200).send({idPartida,pista});
});

router.post('/SeleccionarFicha',jsonParser, async (req,res) => {
  let idPartida = "";
  let matriz = [];
  let pista = "";
  var cont = 0;
  while (cont < juegos.length) {
    let paso = ((new Date().getTime() - juegos[cont].tiempoCreacion) < (1000 * 60 * MaxTime)) ? "activo": "inactivo";
    if(paso === "activo"){
      if (juegos[cont].idPartida == req.query.idPartida){
        juegos[cont].jugadores.forEach(element => {
          if (element.nombre == req.query.nickname){
            juegos[cont].setFichas(req.query.ficha);
            element.setFicha(req.query.ficha);
          }
        })
        idPartida = juegos[cont].idPartida;
        matriz = juegos[cont].matrizJuego;
        pista = juegos[cont].pista;
      }
    }
    cont++;
  }
  return res.status(200).send({idPartida,matriz,pista});
});

module.exports = router;