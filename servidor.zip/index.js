const express = require("express");
const app = express();
const cors = require('cors');
const port = 3001

const juego = require('./Rutas/Juego')

app.use(cors())

app.use('/api/juego',juego);

// app.use(express.static('client/build'));

app.listen(port,() => {
  console.log('Server started on ',port);
})