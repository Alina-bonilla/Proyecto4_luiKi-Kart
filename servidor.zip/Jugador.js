class Jugador{
  nombre;
  ficha;
  vultas;
  i;
  j;
  marca1;
  marca2;
  marca3;
  primerMarca;
  
  constructor (nombre){
    this.nombre = nombre;
    this.ficha = "";
    this.vultas = 0;
    this.marca1 = false;
    this.marca2 = false;
    this.marca3 = false;
    this.primerMarca = 0;
  }

  setFicha(ficha){
    this.ficha = ficha;
  }

  addLab(){
    this.vultas++;
  }

  setMarca1(){
    if(this.primerMarca == 0){
      this.primerMarca = 1;
    }
    this.marca1 = !this.marca1;
  }

  setMarca2(){
    if(this.primerMarca == 0){
      this.primerMarca = 2;
    }
    this.marca2 = !this.marca2;
  }
  
  setMarca3(){
    if(this.primerMarca == 0){
      this.primerMarca = 3;
    }
    this.marca3 = !this.marca3;
  }

  AumentarVVultas(){
    if (this.primerMarca == 1){
      if (this.marca1 && this.marca2 && this.marca3){
        setMarca1();
        setMarca2();
        setMarca3();
        this.vultas ++;
      }
    }
  }
}

module.exports = Jugador