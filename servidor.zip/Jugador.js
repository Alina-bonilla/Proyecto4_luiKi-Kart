class Jugador{
  nombre;
  ficha;
  vultas;
  i;
  j;
  marca1;
  marca2;
  marca3;
  
  constructor (nombre){
    this.nombre = nombre;
    this.ficha = "";
    this.vultas = 0;
    this.marca1 = true;
    this.marca2 = true;
    this.marca3 = true;
  }

  setFicha(ficha){
    this.ficha = ficha;
  }

  addLab(){
    this.vultas++;
  }

  setMarca1(){
    this.marca1 = !this.marca1
  }

  setMarca2(){
    this.marca2 = !this.marca2
  }
  
  setMarca3(){
    this.marca3 = !this.marca3
  }
}

module.exports = Jugador